# SkillBridge - Resume Analysis & Career Guidance Platform
# Uses Streamlit for UI and Google's Gemini API for NLP tasks
# Modified to accept resume input in PDF format only

import streamlit as st
import os
import pandas as pd
import numpy as np
import re
import json
import google.generativeai as genai
from PyPDF2 import PdfReader
from io import BytesIO
import matplotlib.pyplot as plt
import seaborn as sns
from streamlit_option_menu import option_menu

# Set page configuration
st.set_page_config(
    page_title="SkillBridge",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state variables
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'username' not in st.session_state:
    st.session_state.username = ""
if 'extracted_skills' not in st.session_state:
    st.session_state.extracted_skills = []
if 'missing_skills' not in st.session_state:
    st.session_state.missing_skills = []
if 'job_matches' not in st.session_state:
    st.session_state.job_matches = []
if 'course_recommendations' not in st.session_state:
    st.session_state.course_recommendations = []
if 'resume_score' not in st.session_state:
    st.session_state.resume_score = 0
if 'resume_feedback' not in st.session_state:
    st.session_state.resume_feedback = {}
if 'resume_text' not in st.session_state:
    st.session_state.resume_text = ""
if 'job_database' not in st.session_state:
    st.session_state.job_database = [
        {
            "title": "Software Engineer",
            "company": "Tech Solutions Inc.",
            "location": "San Francisco, CA",
            "description": "Develop and maintain software applications using Python, JavaScript, and cloud technologies.",
            "required_skills": ["Python", "JavaScript", "React", "AWS", "Git", "SQL"],
            "preferred_skills": ["Docker", "Kubernetes", "CI/CD", "NoSQL"],
            "salary_range": "$90,000 - $130,000",
            "job_type": "Full-time",
            "match_score": 0
        },
        {
            "title": "Data Scientist",
            "company": "DataCorp Analytics",
            "location": "Boston, MA",
            "description": "Analyze large datasets and build predictive models to drive business decisions.",
            "required_skills": ["Python", "R", "SQL", "Machine Learning", "Statistics", "Data Visualization"],
            "preferred_skills": ["PyTorch", "TensorFlow", "Big Data", "NLP"],
            "salary_range": "$95,000 - $140,000",
            "job_type": "Full-time",
            "match_score": 0
        },
        {
            "title": "Frontend Developer",
            "company": "WebDesign Pro",
            "location": "Remote",
            "description": "Create responsive and user-friendly web interfaces using modern frontend technologies.",
            "required_skills": ["HTML", "CSS", "JavaScript", "React", "TypeScript", "Responsive Design"],
            "preferred_skills": ["Vue.js", "Angular", "UI/UX Design", "SASS"],
            "salary_range": "$80,000 - $120,000",
            "job_type": "Full-time",
            "match_score": 0
        },
        {
            "title": "DevOps Engineer",
            "company": "Cloud Systems Ltd.",
            "location": "Austin, TX",
            "description": "Implement and manage CI/CD pipelines and cloud infrastructure.",
            "required_skills": ["AWS", "Docker", "Kubernetes", "CI/CD", "Linux", "Python"],
            "preferred_skills": ["Terraform", "Ansible", "Monitoring Tools", "Security"],
            "salary_range": "$100,000 - $145,000",
            "job_type": "Full-time",
            "match_score": 0
        },
        {
            "title": "Product Manager",
            "company": "Innovate Inc.",
            "location": "Seattle, WA",
            "description": "Lead product development from conception to launch and coordinate with cross-functional teams.",
            "required_skills": ["Product Management", "Agile", "Market Research", "User Stories", "Roadmapping"],
            "preferred_skills": ["Technical Background", "UX Design", "Data Analysis", "A/B Testing"],
            "salary_range": "$110,000 - $160,000",
            "job_type": "Full-time",
            "match_score": 0
        }
    ]
if 'course_database' not in st.session_state:
    st.session_state.course_database = [
        {
            "title": "Python for Data Science and Machine Learning Bootcamp",
            "provider": "Udemy",
            "skills": ["Python", "Data Science", "Machine Learning", "Pandas", "NumPy", "Matplotlib"],
            "difficulty": "Intermediate",
            "duration": "40 hours",
            "url": "https://www.udemy.com/course/python-for-data-science-and-machine-learning-bootcamp/",
            "price": "$19.99"
        },
        {
            "title": "The Complete Web Developer Course",
            "provider": "Coursera",
            "skills": ["HTML", "CSS", "JavaScript", "React", "Node.js", "MongoDB"],
            "difficulty": "Beginner to Intermediate",
            "duration": "30 hours",
            "url": "https://www.coursera.org/learn/web-development",
            "price": "$49.99"
        },
        {
            "title": "AWS Certified Solutions Architect",
            "provider": "AWS Training",
            "skills": ["AWS", "Cloud Architecture", "EC2", "S3", "Lambda", "CloudFormation"],
            "difficulty": "Advanced",
            "duration": "60 hours",
            "url": "https://aws.amazon.com/training/",
            "price": "$150"
        },
        {
            "title": "DevOps Engineering on AWS",
            "provider": "edX",
            "skills": ["AWS", "DevOps", "CI/CD", "Docker", "Kubernetes", "Infrastructure as Code"],
            "difficulty": "Intermediate to Advanced",
            "duration": "50 hours",
            "url": "https://www.edx.org/professional-certificate/aws-devops-engineering",
            "price": "$99"
        },
        {
            "title": "Data Science: R Basics",
            "provider": "Harvard Online",
            "skills": ["R", "Data Science", "Statistics", "Data Analysis", "Data Visualization"],
            "difficulty": "Beginner",
            "duration": "20 hours",
            "url": "https://online-learning.harvard.edu/course/data-science-r-basics",
            "price": "Free"
        }
    ]
if 'career_insights' not in st.session_state:
    st.session_state.career_insights = {}
if 'user_database' not in st.session_state:
    st.session_state.user_database = {
        "user1": {"password": "pass1", "name": "John Doe", "email": "john@example.com"},
        "user2": {"password": "pass2", "name": "Jane Smith", "email": "jane@example.com"}
    }

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.8rem;
        font-weight: 600;
        color: #333;
        margin-top: 1.5rem;
        margin-bottom: 1rem;
    }
    .card {
        border-radius: 10px;
        padding: 20px;
        margin: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .blue-card {
        background-color: #E3F2FD;
        border-left: 5px solid #1E88E5;
    }
    .green-card {
        background-color: #E8F5E9;
        border-left: 5px solid #4CAF50;
    }
    .orange-card {
        background-color: #FFF3E0;
        border-left: 5px solid #FF9800;
    }
    .red-card {
        background-color: #FFEBEE;
        border-left: 5px solid #F44336;
    }
    .skill-tag {
        background-color: #1E88E5;
        color: white;
        padding: 5px 10px;
        border-radius: 15px;
        margin: 2px;
        display: inline-block;
        font-size: 0.8rem;
    }
    .missing-skill-tag {
        background-color: #F44336;
        color: white;
        padding: 5px 10px;
        border-radius: 15px;
        margin: 2px;
        display: inline-block;
        font-size: 0.8rem;
    }
    .job-card {
        background-color: white;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border-left: 5px solid #1E88E5;
    }
    .course-card {
        background-color: white;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border-left: 5px solid #4CAF50;
    }
    .stButton>button {
        background-color: #1E88E5;
        color: white;
        font-weight: bold;
        width: 100%;
    }
</style>
""", unsafe_allow_html=True)

# Function to configure Gemini API
def configure_gemini_api():
    # Directly use the API key without secrets
    api_key = "AIzaSyCMk4SBFz03LFlcJchFGCAjOi095O0fejQ"  
    
    # If key is missing or empty, get from user input
    if not api_key:
        api_key = st.text_input("Enter your Gemini API Key:", type="password")
        if not api_key:
            st.warning("Please enter a Gemini API key to continue")
            st.stop()
    
    try:
        genai.configure(api_key=api_key)
        return genai.GenerativeModel('gemini-pro')
    except Exception as e:
        st.error(f"Failed to configure Gemini API: {e}")
        st.stop()
    
    try:
        genai.configure(api_key=api_key)
        return genai.GenerativeModel('gemini-pro')
    except Exception as e:
        st.error(f"Failed to configure Gemini API: {e}")
        st.stop()

# Extract text from uploaded resume (PDF only)
def extract_text_from_resume(uploaded_file):
    if uploaded_file is not None:
        file_ext = os.path.splitext(uploaded_file.name)[1].lower()
        
        if file_ext == '.pdf':
            try:
                pdf_reader = PdfReader(BytesIO(uploaded_file.read()))
                text = ""
                for page in pdf_reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text
                return text
            except Exception as e:
                st.error(f"Error extracting text from PDF: {e}")
                return ""
        else:
            st.error("Please upload a PDF file. Only PDF format is supported.")
            return ""
    return ""

# Extract skills from resume text using Gemini
def extract_skills(resume_text, model):
    prompt = f"""
    You are an expert ATS (Applicant Tracking System) and resume parser. 
    Extract a comprehensive list of technical skills, tools, programming languages, frameworks, 
    and soft skills from the following resume text. 
    
    Focus on identifying:
    1. Programming languages (e.g., Python, Java, C++)
    2. Frameworks and libraries (e.g., React, TensorFlow, Django)
    3. Tools and platforms (e.g., AWS, Docker, Photoshop)
    4. Databases (e.g., MySQL, MongoDB)
    5. Methodologies (e.g., Agile, Scrum, DevOps)
    6. Soft skills (e.g., Leadership, Communication, Project Management)
    
    Format your response as a JSON array of strings with ONLY the skills. Do not include any explanations, just the JSON array.
    
    Resume text:
    {resume_text}
    """
    
    try:
        response = model.generate_content(prompt)
        skills_text = response.text.strip()
        
        skills_match = re.search(r'\[(.*)\]', skills_text, re.DOTALL)
        if skills_match:
            skills_json = f"[{skills_match.group(1)}]"
            skills = json.loads(skills_json)
        else:
            try:
                skills = json.loads(skills_text)
            except:
                skills = [s.strip(' "\'') for s in skills_text.split(',')]
                skills = [s for s in skills if s and len(s) > 1]
        
        if isinstance(skills, list):
            return skills
        return []
            
    except Exception as e:
        st.error(f"Error extracting skills: {e}")
        return []

# Compare resume with job requirements and identify gaps
def identify_skill_gaps(extracted_skills, job_database, model):
    all_job_skills = set()
    for job in job_database:
        all_job_skills.update(job["required_skills"])
        all_job_skills.update(job["preferred_skills"])
    
    all_job_skills = list(all_job_skills)
    
    prompt = f"""
    You are a career advisor and skills gap analyst.
    
    The candidate has the following skills:
    {extracted_skills}
    
    The job market currently demands these skills:
    {all_job_skills}
    
    Identify the top 10 most important skills the candidate is missing to be competitive in the current job market.
    Consider relevance, demand, and how these skills complement the candidate's existing skillset.
    Format your response as a JSON array of strings with ONLY the missing skills. Do not include any explanations, just the JSON array.
    """
    
    try:
        response = model.generate_content(prompt)
        missing_skills_text = response.text.strip()
        
        missing_skills_match = re.search(r'\[(.*)\]', missing_skills_text, re.DOTALL)
        if missing_skills_match:
            missing_skills_json = f"[{missing_skills_match.group(1)}]"
            missing_skills = json.loads(missing_skills_json)
        else:
            try:
                missing_skills = json.loads(missing_skills_text)
            except:
                missing_skills = [s.strip(' "\'') for s in missing_skills_text.split(',')]
                missing_skills = [s for s in missing_skills if s and len(s) > 1]
        
        return missing_skills
            
    except Exception as e:
        st.error(f"Error identifying skill gaps: {e}")
        return []

# Score resume against jobs and find matches
def match_jobs(extracted_skills, job_database):
    matched_jobs = []
    
    for job in job_database:
        job_copy = job.copy()
        required_matches = sum(1 for skill in job["required_skills"] if skill in extracted_skills)
        preferred_matches = sum(1 for skill in job["preferred_skills"] if skill in extracted_skills)
        
        total_required = len(job["required_skills"])
        total_preferred = len(job["preferred_skills"])
        
        required_score = (required_matches / total_required) if total_required > 0 else 0
        preferred_score = (preferred_matches / total_preferred) if total_preferred > 0 else 0
        
        match_score = (required_score * 0.7 + preferred_score * 0.3) * 100
        job_copy["match_score"] = round(match_score, 1)
        
        matched_jobs.append(job_copy)
    
    matched_jobs.sort(key=lambda x: x["match_score"], reverse=True)
    return matched_jobs

# Recommend courses for missing skills
def recommend_courses(missing_skills, course_database):
    recommended_courses = []
    
    for skill in missing_skills:
        skill_lower = skill.lower()
        matching_courses = []
        for course in course_database:
            course_skills = [s.lower() for s in course["skills"]]
            if any(skill_lower in cs for cs in course_skills):
                matching_courses.append(course)
        recommended_courses.extend(matching_courses)
    
    unique_courses = []
    seen_titles = set()
    
    for course in recommended_courses:
        if course["title"] not in seen_titles:
            seen_titles.add(course["title"])
            unique_courses.append(course)
    
    return unique_courses[:5]

# Generate career insights using Gemini
def generate_career_insights(resume_text, extracted_skills, missing_skills, model):
    prompt = f"""
    You are a professional career advisor and mentor. Based on the following resume information and skills analysis,
    provide insightful career guidance for this candidate.
    
    Resume text:
    {resume_text[:2000]}...
    
    Extracted skills:
    {extracted_skills}
    
    Skill gaps identified:
    {missing_skills}
    
    Provide the following in JSON format:
    1. A brief analysis of the candidate's current profile
    2. Career path recommendations based on their skills
    3. Industry trends relevant to their background
    4. Mentorship and networking suggestions
    5. Long-term growth opportunities
    
    Format as a JSON object with keys: "profile_analysis", "career_paths", "industry_trends", "mentorship_suggestions", "growth_opportunities".
    """
    
    try:
        response = model.generate_content(prompt)
        insights_text = response.text.strip()
        
        json_match = re.search(r'json\s*(.?)\s', insights_text, re.DOTALL)
        if json_match:
            insights_json = json_match.group(1)
        else:
            json_match = re.search(r'({.*})', insights_text, re.DOTALL)
            insights_json = json_match.group(1) if json_match else insights_text
        
        insights = json.loads(insights_json)
        return insights
            
    except Exception as e:
        st.error(f"Error generating career insights: {e}")
        return {
            "profile_analysis": "Unable to generate profile analysis.",
            "career_paths": ["Consider roles that match your current skills"],
            "industry_trends": ["Focus on the latest technologies in your field"],
            "mentorship_suggestions": ["Connect with professionals in your target industry"],
            "growth_opportunities": ["Continue developing your technical and soft skills"]
        }

# Generate resume feedback using Gemini
def generate_resume_feedback(resume_text, model):
    prompt = f"""
    You are an expert resume reviewer who helps candidates improve their resumes to pass ATS systems and impress hiring managers.
    Review the following resume text and provide constructive feedback.
    
    Resume text:
    {resume_text[:3000]}...
    
    Provide feedback in JSON format with:
    1. Overall score (0-100)
    2. Strengths (list of strong points)
    3. Weaknesses (list of areas for improvement)
    4. ATS optimization tips (list of suggestions to improve ATS compatibility)
    5. Format and structure suggestions (list of formatting recommendations)
    
    Format as a JSON object with keys: "score", "strengths", "weaknesses", "ats_tips", "format_suggestions".
    """
    
    try:
        response = model.generate_content(prompt)
        feedback_text = response.text.strip()
        
        json_match = re.search(r'json\s*(.?)\s', feedback_text, re.DOTALL)
        if json_match:
            feedback_json = json_match.group(1)
        else:
            json_match = re.search(r'({.*})', feedback_text, re.DOTALL)
            feedback_json = json_match.group(1) if json_match else feedback_text
        
        feedback = json.loads(feedback_json)
        return feedback
            
    except Exception as e:
        st.error(f"Error generating resume feedback: {e}")
        return {
            "score": 70,
            "strengths": ["Unable to analyze resume strengths"],
            "weaknesses": ["Unable to analyze resume weaknesses"],
            "ats_tips": ["Ensure your resume includes relevant keywords"],
            "format_suggestions": ["Use a clean, ATS-friendly format"]
        }

# Login function
def login(username, password):
    if username in st.session_state.user_database:
        if st.session_state.user_database[username]["password"] == password:
            st.session_state.logged_in = True
            st.session_state.username = username
            return True
    return False

# Register function
def register(username, password, name, email):
    if username in st.session_state.user_database:
        return False
    st.session_state.user_database[username] = {
        "password": password,
        "name": name,
        "email": email
    }
    return True

# Logout function
def logout():
    st.session_state.logged_in = False
    st.session_state.username = ""

# Main application
def main():
    model = configure_gemini_api()
    
    with st.sidebar:
        st.image("https://img.icons8.com/color/96/000000/rocket--v1.png", width=100)
        st.markdown("<h1 style='text-align: center;'>Skill Bridge</h1>", unsafe_allow_html=True)
        st.markdown("---")
        
        if st.session_state.logged_in:
            st.write(f"Welcome, {st.session_state.user_database[st.session_state.username]['name']}!")
            
            selected = option_menu(
                "Navigation",
                ["Dashboard", "Resume Analysis", "Job Matching", "Course Recommendations", "Career Insights", "Profile"],
                icons=["house", "file-earmark-text", "briefcase", "book", "graph-up", "person"],
                menu_icon="cast",
                default_index=0,
            )
            
            if st.button("Logout"):
                logout()
                st.experimental_rerun()
        else:
            selected = option_menu(
                "Navigation",
                ["Login", "Register"],
                icons=["box-arrow-in-right", "person-plus"],
                menu_icon="cast",
                default_index=0,
            )
    
    if not st.session_state.logged_in:
        if selected == "Login":
            login_page()
        elif selected == "Register":
            register_page()
    else:
        if selected == "Dashboard":
            dashboard_page()
        elif selected == "Resume Analysis":
            resume_analysis_page(model)
        elif selected == "Job Matching":
            job_matching_page()
        elif selected == "Course Recommendations":
            course_recommendations_page()
        elif selected == "Career Insights":
            career_insights_page(model)
        elif selected == "Profile":
            profile_page()

# Login page
def login_page():
    st.markdown("<h1 class='main-header'>Welcome to Skill Bridge</h1>", unsafe_allow_html=True)
    st.markdown("Bridge the gap between your skills and dream job opportunities")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.markdown("<h2 class='sub-header'>Login</h2>", unsafe_allow_html=True)
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        
        if st.button("Login"):
            if login(username, password):
                st.success("Login successful!")
                st.experimental_rerun()
            else:
                st.error("Invalid username or password")

# Register page
def register_page():
    st.markdown("<h1 class='main-header'>Create an Account</h1>", unsafe_allow_html=True)
    st.markdown("Join Skill Bridge to access personalized career guidance")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.markdown("<h2 class='sub-header'>Register</h2>", unsafe_allow_html=True)
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        name = st.text_input("Full Name")
        email = st.text_input("Email")
        
        if st.button("Register"):
            if username and password and name and email:
                if register(username, password, name, email):
                    st.success("Registration successful! Please login.")
                    login(username, password)
                    st.experimental_rerun()
                else:
                    st.error("Username already exists")
            else:
                st.error("Please fill all fields")

# Dashboard page
def dashboard_page():
    st.markdown("<h1 class='main-header'>Your Career Dashboard</h1>", unsafe_allow_html=True)
    
    has_resume_data = len(st.session_state.extracted_skills) > 0
    
    if not has_resume_data:
        st.info("Upload your resume in the Resume Analysis section to get started!")
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("<div class='card blue-card'><h3>How It Works</h3><p>SkillBridge analyzes your resume, identifies skill gaps, and provides personalized recommendations to boost your career.</p></div>", unsafe_allow_html=True)
        with col2:
            st.markdown("<div class='card green-card'><h3>Get Started</h3><p>1. Upload your PDF resume<br>2. Review skill analysis<br>3. Explore job matches<br>4. Find relevant courses</p></div>", unsafe_allow_html=True)
    else:
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("<h2 class='sub-header'>Your Skills</h2>", unsafe_allow_html=True)
            
            st.markdown("<div class='card blue-card'><h3>Skills Identified</h3>", unsafe_allow_html=True)
            for skill in st.session_state.extracted_skills:
                st.markdown(f"<span class='skill-tag'>{skill}</span>", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)
            
            if st.session_state.missing_skills:
                st.markdown("<div class='card red-card'><h3>Skills to Learn</h3>", unsafe_allow_html=True)
                for skill in st.session_state.missing_skills:
                    st.markdown(f"<span class='missing-skill-tag'>{skill}</span>", unsafe_allow_html=True)
                st.markdown("</div>", unsafe_allow_html=True)
        
        with col2:
            st.markdown("<h2 class='sub-header'>Quick Stats</h2>", unsafe_allow_html=True)
            
            st.markdown(f"<div class='card green-card'><h3>Resume Score</h3><p>{st.session_state.resume_score}/100</p></div>", unsafe_allow_html=True)
            
            job_count = len([job for job in st.session_state.job_matches if job['match_score'] >= 50])
            st.markdown(f"<div class='card orange-card'><h3>Job Matches</h3><p>{job_count} potential opportunities</p></div>", unsafe_allow_html=True)
            
            course_count = len(st.session_state.course_recommendations)
            st.markdown(f"<div class='card blue-card'><h3>Course Recommendations</h3><p>{course_count} courses to bridge skill gaps</p></div>", unsafe_allow_html=True)

# Resume analysis page
def resume_analysis_page(model):
    st.markdown("<h1 class='main-header'>Resume Analysis</h1>", unsafe_allow_html=True)
    
    st.markdown("<h2 class='sub-header'>Upload Your Resume</h2>", unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Upload your resume (PDF only)", type=['pdf'], accept_multiple_files=False)
    
    if uploaded_file:
        with st.spinner("Analyzing your resume..."):
            resume_text = extract_text_from_resume(uploaded_file)
            if resume_text:
                st.session_state.resume_text = resume_text
                
                extracted_skills = extract_skills(resume_text, model)
                st.session_state.extracted_skills = extracted_skills
                
                missing_skills = identify_skill_gaps(extracted_skills, st.session_state.job_database, model)
                st.session_state.missing_skills = missing_skills
                
                job_matches = match_jobs(extracted_skills, st.session_state.job_database)
                st.session_state.job_matches = job_matches
                
                course_recommendations = recommend_courses(missing_skills, st.session_state.course_database)
                st.session_state.course_recommendations = course_recommendations
                
                resume_feedback = generate_resume_feedback(resume_text, model)
                st.session_state.resume_feedback = resume_feedback
                st.session_state.resume_score = resume_feedback.get('score', 70)
                
                career_insights = generate_career_insights(resume_text, extracted_skills, missing_skills, model)
                st.session_state.career_insights = career_insights
                
                st.success("Resume analysis complete!")
    
    if st.session_state.resume_text:
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("<h2 class='sub-header'>Extracted Skills</h2>", unsafe_allow_html=True)
            if st.session_state.extracted_skills:
                st.markdown("<div class='card blue-card'>", unsafe_allow_html=True)
                for skill in st.session_state.extracted_skills:
                    st.markdown(f"<span class='skill-tag'>{skill}</span>", unsafe_allow_html=True)
                st.markdown("</div>", unsafe_allow_html=True)
            else:
                st.warning("No skills extracted from the resume.")
        
        with col2:
            st.markdown("<h2 class='sub-header'>Missing Skills</h2>", unsafe_allow_html=True)
            if st.session_state.missing_skills:
                st.markdown("<div class='card red-card'>", unsafe_allow_html=True)
                for skill in st.session_state.missing_skills:
                    st.markdown(f"<span class='missing-skill-tag'>{skill}</span>", unsafe_allow_html=True)
                st.markdown("</div>", unsafe_allow_html=True)
            else:
                st.info("No critical skill gaps identified.")
        
        st.markdown("<h2 class='sub-header'>Resume Feedback</h2>", unsafe_allow_html=True)
        if st.session_state.resume_feedback:
            feedback = st.session_state.resume_feedback
            st.markdown(f"<div class='card green-card'><h3>Resume Score: {feedback.get('score', 70)}/100</h3></div>", unsafe_allow_html=True)
            
            st.markdown("<div class='card blue-card'><h3>Strengths</h3>", unsafe_allow_html=True)
            for strength in feedback.get('strengths', []):
                st.markdown(f"- {strength}")
            st.markdown("</div>", unsafe_allow_html=True)
            
            st.markdown("<div class='card red-card'><h3>Weaknesses</h3>", unsafe_allow_html=True)
            for weakness in feedback.get('weaknesses', []):
                st.markdown(f"- {weakness}")
            st.markdown("</div>", unsafe_allow_html=True)
            
            st.markdown("<div class='card orange-card'><h3>ATS Optimization Tips</h3>", unsafe_allow_html=True)
            for tip in feedback.get('ats_tips', []):
                st.markdown(f"- {tip}")
            st.markdown("</div>", unsafe_allow_html=True)
            
            st.markdown("<div class='card blue-card'><h3>Format Suggestions</h3>", unsafe_allow_html=True)
            for suggestion in feedback.get('format_suggestions', []):
                st.markdown(f"- {suggestion}")
            st.markdown("</div>", unsafe_allow_html=True)

# Job matching page
def job_matching_page():
    st.markdown("<h1 class='main-header'>Job Matching</h1>", unsafe_allow_html=True)
    
    if not st.session_state.job_matches:
        st.info("Upload your resume in the Resume Analysis section to see job matches.")
        return
    
    st.markdown("<h2 class='sub-header'>Your Top Job Matches</h2>", unsafe_allow_html=True)
    
    for job in st.session_state.job_matches[:5]:
        st.markdown("<div class='job-card'>", unsafe_allow_html=True)
        st.markdown(f"{job['title']}** at {job['company']}")
        st.markdown(f"Location: {job['location']} | **Salary: {job['salary_range']} | **Type: {job['job_type']}")
        st.markdown(f"Match Score: {job['match_score']}%")
        st.markdown(f"Description: {job['description']}")
        st.markdown("Required Skills: " + ", ".join(job['required_skills']))
        st.markdown("Preferred Skills: " + ", ".join(job['preferred_skills']))
        st.markdown("</div>", unsafe_allow_html=True)

# Course recommendations page
def course_recommendations_page():
    st.markdown("<h1 class='main-header'>Course Recommendations</h1>", unsafe_allow_html=True)
    
    if not st.session_state.course_recommendations:
        st.info("Upload your resume in the Resume Analysis section to get course recommendations.")
        return
    
    st.markdown("<h2 class='sub-header'>Recommended Courses</h2>", unsafe_allow_html=True)
    
    for course in st.session_state.course_recommendations:
        st.markdown("<div class='course-card'>", unsafe_allow_html=True)
        st.markdown(f"{course['title']}** by {course['provider']}")
        st.markdown(f"Skills: {', '.join(course['skills'])}")
        st.markdown(f"Difficulty: {course['difficulty']} | **Duration: {course['duration']} | **Price: {course['price']}")
        st.markdown(f"[Enroll Now]({course['url']})")
        st.markdown("</div>", unsafe_allow_html=True)

# Career insights page
def career_insights_page(model):
    st.markdown("<h1 class='main-header'>Career Insights</h1>", unsafe_allow_html=True)
    
    if not st.session_state.career_insights:
        st.info("Upload your resume in the Resume Analysis section to get career insights.")
        return
    
    insights = st.session_state.career_insights
    
    st.markdown("<h2 class='sub-header'>Profile Analysis</h2>", unsafe_allow_html=True)
    st.markdown(f"<div class='card blue-card'>{insights.get('profile_analysis', 'No analysis available.')}</div>", unsafe_allow_html=True)
    
    st.markdown("<h2 class='sub-header'>Career Paths</h2>", unsafe_allow_html=True)
    st.markdown("<div class='card green-card'>", unsafe_allow_html=True)
    for path in insights.get('career_paths', []):
        st.markdown(f"- {path}")
    st.markdown("</div>", unsafe_allow_html=True)
    
    st.markdown("<h2 class='sub-header'>Industry Trends</h2>", unsafe_allow_html=True)
    st.markdown("<div class='card orange-card'>", unsafe_allow_html=True)
    for trend in insights.get('industry_trends', []):
        st.markdown(f"- {trend}")
    st.markdown("</div>", unsafe_allow_html=True)
    
    st.markdown("<h2 class='sub-header'>Mentorship Suggestions</h2>", unsafe_allow_html=True)
    st.markdown("<div class='card blue-card'>", unsafe_allow_html=True)
    for suggestion in insights.get('mentorship_suggestions', []):
        st.markdown(f"- {suggestion}")
    st.markdown("</div>", unsafe_allow_html=True)
    
    st.markdown("<h2 class='sub-header'>Growth Opportunities</h2>", unsafe_allow_html=True)
    st.markdown("<div class='card green-card'>", unsafe_allow_html=True)
    for opportunity in insights.get('growth_opportunities', []):
        st.markdown(f"- {opportunity}")
    st.markdown("</div>", unsafe_allow_html=True)

# Profile page
def profile_page():
    st.markdown("<h1 class='main-header'>Your Profile</h1>", unsafe_allow_html=True)
    
    user_info = st.session_state.user_database.get(st.session_state.username, {})
    
    st.markdown("<h2 class='sub-header'>Personal Information</h2>", unsafe_allow_html=True)
    st.markdown("<div class='card blue-card'>", unsafe_allow_html=True)
    st.markdown(f"Name: {user_info.get('name', 'N/A')}")
    st.markdown(f"Email: {user_info.get('email', 'N/A')}")
    st.markdown(f"Username: {st.session_state.username}")
    st.markdown("</div>", unsafe_allow_html=True)
    
    st.markdown("<h2 class='sub-header'>Update Profile</h2>", unsafe_allow_html=True)
    with st.form("update_profile"):
        new_name = st.text_input("Full Name", value=user_info.get('name', ''))
        new_email = st.text_input("Email", value=user_info.get('email', ''))
        new_password = st.text_input("New Password (leave blank to keep current)", type="password")
        
        if st.form_submit_button("Update Profile"):
            if new_name and new_email:
                st.session_state.user_database[st.session_state.username]['name'] = new_name
                st.session_state.user_database[st.session_state.username]['email'] = new_email
                if new_password:
                    st.session_state.user_database[st.session_state.username]['password'] = new_password
                st.success("Profile updated successfully!")
            else:
                st.error("Please fill in name and email.")

if __name__ == "__main__":
    main()